<?php
// Get My UDID  (built-in, no third-party site)
//  1) GET  udid.php?profile=1 -> sends a tiny "Profile Service" profile (asks the iPhone for its UDID only)
//  2) POST udid.php           -> iOS sends the signed device info here; we read the UDID and
//                                redirect (HTTP 301) back to the website:  /?udid=XXXX
$host = preg_replace('/[^A-Za-z0-9.:-]/', '', (string)($_SERVER['HTTP_HOST'] ?? ''));
if ($host === '') $host = 'ashtemobile.site';
$base = 'https://' . $host;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $raw = file_get_contents('php://input');
    $udid = '';
    if (preg_match('/<plist.*?<\/plist>/s', (string)$raw, $m)) {
        $xml = $m[0];
        if (preg_match('/<key>UDID<\/key>\s*<string>([^<]+)<\/string>/', $xml, $u)) $udid = strtoupper(trim($u[1]));
    }
    if (!preg_match('/^[0-9A-F]{8}-[0-9A-F]{16}$/', $udid) && !preg_match('/^[0-9A-F]{40}$/', $udid)) {
        http_response_code(400);
        exit('Invalid device data');
    }
    header('Cache-Control: no-store');
    header('Location: ' . $base . '/?udid=' . rawurlencode($udid), true, 301);
    exit;
}

// GET -> profile download
$uuid1 = 'A5B7C1D2-3E4F-4A6B-8C9D-0E1F2A3B4C5D';
$uuid2 = 'B6C8D2E3-4F50-4B7C-9DAE-1F203B4C5D6E';
$x = '<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
	<key>PayloadContent</key>
	<dict>
		<key>URL</key>
		<string>' . $base . '/udid.php</string>
		<key>DeviceAttributes</key>
		<array>
			<string>UDID</string>
			<string>PRODUCT</string>
			<string>VERSION</string>
		</array>
	</dict>
	<key>PayloadOrganization</key>
	<string>AshteMobile</string>
	<key>PayloadDisplayName</key>
	<string>AshteMobile - Get UDID</string>
	<key>PayloadDescription</key>
	<string>Reads your device UDID once, so the admin can activate VIP. Nothing else is collected.</string>
	<key>PayloadVersion</key>
	<integer>1</integer>
	<key>PayloadUUID</key>
	<string>' . $uuid1 . '</string>
	<key>PayloadIdentifier</key>
	<string>site.ashtemobile.getudid</string>
	<key>PayloadType</key>
	<string>Profile Service</string>
</dict>
</plist>';
header('Content-Type: application/x-apple-aspen-config; charset=utf-8');
header('Content-Disposition: attachment; filename="AshteMobile-UDID.mobileconfig"');
header('Cache-Control: no-store');
echo $x;
